/**
 * @file extension constants variables
 * @author xcv58
 */

export const GITHUB_OAUTH_TOKEN = 'github-oauth-token';
