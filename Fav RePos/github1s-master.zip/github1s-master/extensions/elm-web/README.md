# This extension is a fork from [elm-language-client-vscode](https://github.com/elm-tooling/elm-language-client-vscode) for github1s.

# At present only languages features is reserved

# I have deleted some files and only reserved the necessary code

# Elm Plugin for Visual Studio Code (VSCode)

[![Version](https://vsmarketplacebadge.apphb.com/version/Elmtooling.elm-ls-vscode.svg)](https://marketplace.visualstudio.com/items?itemName=Elmtooling.elm-ls-vscode)
[![Downloads](https://vsmarketplacebadge.apphb.com/downloads-short/Elmtooling.elm-ls-vscode.svg)](https://marketplace.visualstudio.com/items?itemName=Elmtooling.elm-ls-vscode)
[![Rating](https://vsmarketplacebadge.apphb.com/rating-star/Elmtooling.elm-ls-vscode.svg)](https://marketplace.visualstudio.com/items?itemName=Elmtooling.elm-ls-vscode)
![Compile](https://github.com/elm-tooling/elm-language-client-vscode/workflows/Compile/badge.svg)

Supports elm 0.19 and up

## Highlighted Features

- Syntax Highlighting
