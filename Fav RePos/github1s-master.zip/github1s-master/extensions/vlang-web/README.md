# This extension is a fork from [vscode-vlang](https://github.com/vlang/vscode-vlang) for github1s.

# At present only languages features is reserved

# I have deleted some files and only reserved the necessary code

# V language support for Visual Studio Code

[![Version](https://vsmarketplacebadge.apphb.com/version/vlanguage.vscode-vlang.svg)](https://marketplace.visualstudio.com/items?itemName=vlanguage.vscode-vlang)
[![Installs](https://vsmarketplacebadge.apphb.com/installs/vlanguage.vscode-vlang.svg)](https://marketplace.visualstudio.com/items?itemName=vlanguage.vscode-vlang)
![GitHub Workflow Status](https://img.shields.io/github/workflow/status/vlang/vscode-vlang/CI)

Provides [V language](https://vlang.io) support for Visual Studio Code.

## Features

- Syntax Highlighting

## License

[MIT](./LICENSE)
