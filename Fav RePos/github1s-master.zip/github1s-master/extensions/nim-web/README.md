# This extension is a fork from [vscode-nim](https://github.com/saem/vscode-nim) for github1s

# At present only languages features is reserved

# I have deleted some files and only reserved the necessary code

# Nim Extension

Visual Studio:
[![Version](https://vsmarketplacebadge.apphb.com/version/nimsaem.nimvscode.svg)](https://marketplace.visualstudio.com/items?itemName=nimsaem.nimvscode)
[![Ratings](https://vsmarketplacebadge.apphb.com/rating/nimsaem.nimvscode.svg)](https://vsmarketplacebadge.apphb.com/rating/nimsaem.nimvscode.svg)

Open-VSX:
[![Version](https://img.shields.io/open-vsx/v/nimsaem/nimvscode)](https://open-vsx.org/extension/nimsaem/nimvscode)
[![Installs](https://img.shields.io/open-vsx/dt/nimsaem/nimvscode)](https://open-vsx.org/extension/nimsaem/nimvscode)
[![Ratings](https://img.shields.io/open-vsx/rating/nimsaem/nimvscode)](https://open-vsx.org/extension/nimsaem/nimvscode)

This extension adds language support for the Nim language to VS Code, including:

- Syntax Highlight (nim, nimble, nim.cfg)
